# Firebase Firestore Read Optimization Guide

## 🚨 Current Problem
Your app has **7 active onSnapshot listeners** running continuously, causing:
- **31K reads in 5 hours** (just from development)
- Firebase no-cost limit: 50K reads/day
- At current rate: ~150K reads/day = **3x over limit**
- This will cost money in production!

## ✅ Solution Implemented

### 1. Global Data Provider (`src/config/DataProvider.js`)
**Created a centralized data management system with:**
- ✅ **Caching**: Data is fetched once and reused
- ✅ **Cache Duration**: 5-minute cache prevents repeated reads
- ✅ **Manual Refresh**: User can trigger fresh data when needed
- ✅ **No Real-time Listeners**: Uses `getDocs` instead of `onSnapshot`
- ✅ **Limited Queries**: Contacts limited to 50 most recent

### 2. Updated App Structure
```javascript
<Router>
  <AuthProvider>
    <DataProvider>  {/* ← New provider wraps all pages */}
      <Routes>
        <Route path="*" element={<AppContent />} />
      </Routes>
    </DataProvider>
  </AuthProvider>
</Router>
```

## 📋 Files That Need Updates

###  Pages Using `onSnapshot` (MUST FIX):

1. **✅ Home.jsx** - PARTIALLY UPDATED
   - Changed to use `useData()` hook
   - Added manual refresh button
   - Still needs: Update all `loading` to `loading.reservations`

2. **❌ Menu.jsx**
   - Current: Uses `onSnapshot(menuRef, ...)`
   - Fix: Use `const { menuItems, fetchMenuItems } = useData();`
   
3. **❌ AllReservations.jsx**
   - Current: Uses `onSnapshot(allReservationsRef, ...)`
   - Fix: Use `const { reservations, fetchReservations } = useData();`

4. **❌ UpcomingReservations.jsx**
   - Current: Uses `onSnapshot(allReservationsRef, ...)`
   - Fix: Use `const { reservations } = useData();` + filter locally

5. **❌ PastReservations.jsx**
   - Current: Uses `onSnapshot(allReservationsRef, ...)`
   - Fix: Use `const { reservations } = useData();` + filter locally

6. **❌ ReservationOverview.jsx**
   - Current: Uses `onSnapshot(allReservationsRef, ...)`
   - Fix: Use `const { reservations } = useData();`

7. **❌ ContactForm.jsx**
   - Current: Uses `onSnapshot(contactFormRef, ...)`
   - Fix: Use `const { contacts, fetchContacts } = useData();`

8. **✅ Appbar.jsx** - CAN KEEP (single doc read)
   - Current: Uses `onSnapshot(userDocRef, ...)` 
   - This is OK: Only reads 1 document for user settings
   - Alternative: Use `const { userSettings } = useData();`

## 🔧 How to Fix Each Page

### Example: Menu.jsx

**BEFORE (BAD - reads on every change):**
```javascript
useEffect(() => {
  const menuRef = collection(db, 'menu');
  const unsubscribe = onSnapshot(menuRef, (snapshot) => {
    const items = [];
    snapshot.forEach((doc) => {
      items.push({ id: doc.id, ...doc.data() });
    });
    setMenuItems(items);
  });
  return () => unsubscribe();
}, []);
```

**AFTER (GOOD - uses cached data):**
```javascript
import { useData } from '../../../config/DataProvider';

const Menu = () => {
  const { menuItems, loading, fetchMenuItems } = useData();
  const [refreshing, setRefreshing] = useState(false);

  const handleRefresh = async () => {
    setRefreshing(true);
    await fetchMenuItems(true); // Force refresh
    setRefreshing(false);
  };

  // menuItems is already available, no useEffect needed!
  // Add refresh button in UI:
  <IconButton onClick={handleRefresh} disabled={refreshing}>
    <RefreshIcon />
  </IconButton>
}
```

### Example: AllReservations.jsx

**BEFORE:**
```javascript
useEffect(() => {
  const allReservationsRef = collection(db, 'AllReservations');
  const unsubscribe = onSnapshot(allReservationsRef, (snapshot) => {
    // Process reservations...
  });
  return () => unsubscribe();
}, []);
```

**AFTER:**
```javascript
import { useData } from '../../../config/DataProvider';

const AllReservations = () => {
  const { reservations, loading, fetchReservations } = useData();
  
  // Use reservations directly - it's already fetched and cached!
  // Add manual refresh if needed:
  const handleRefresh = () => fetchReservations(true);
}
```

## 📊 Expected Results After Full Implementation

| Metric | Before | After | Savings |
|--------|--------|-------|---------|
| Snapshot Listeners | 7 active | 1 (optional) | -86% |
| Initial Page Load | ~10-15 reads/page | ~3 reads total | -80% |
| Every Page Navigation | ~5-10 reads | 0 reads (cached) | -100% |
| Hourly Reads (dev) | ~6,200 | ~50-100 | -98% |
| Daily Reads (dev) | ~150,000 | ~1,200 | -99% |
| Monthly Cost | ~$18 | FREE | $18 saved |

## 🎯 Priority Actions

### Immediate (TODAY):
1. ✅ DataProvider is created
2. ✅ App.js updated with DataProvider
3. ⚠️ Fix Home.jsx loading states
4. ❌ Update Menu.jsx (highest reads)
5. ❌ Update AllReservations.jsx

### This Week:
6. ❌ Update UpcomingReservations.jsx
7. ❌ Update PastReservations.jsx
8. ❌ Update ReservationOverview.jsx
9. ❌ Update ContactForm.jsx
10. ✅ Test everything thoroughly

## 🛠️ Quick Fix Template

For any page using `onSnapshot`:

1. **Remove Firebase imports:**
   ```javascript
   // DELETE THESE:
   import { collection, onSnapshot } from 'firebase/firestore';
   import { db } from '../../../config/firebase';
   ```

2. **Add DataProvider import:**
   ```javascript
   import { useData } from '../../../config/DataProvider';
   ```

3. **Remove useEffect with onSnapshot:**
   ```javascript
   // DELETE THIS ENTIRE useEffect:
   useEffect(() => {
     const ref = collection(db, 'collectionName');
     const unsubscribe = onSnapshot(ref, ...);
     return () => unsubscribe();
   }, []);
   ```

4. **Use cached data:**
   ```javascript
   const { reservations, menuItems, contacts, loading } = useData();
   ```

5. **Add refresh button (optional):**
   ```javascript
   const { fetchReservations } = useData();
   const handleRefresh = () => fetchReservations(true);
   ```

## 💡 Best Practices

### DO ✅:
- Use `useData()` hook to access cached data
- Call `fetch*()` with `true` only when user explicitly refreshes
- Use `loading` states from DataProvider
- Share data across components

### DON'T ❌:
- Use `onSnapshot` for collections (use `getDocs` instead)
- Fetch same data multiple times
- Call `fetch*()` in useEffect without checking cache
- Use real-time listeners unless absolutely necessary

## 🔍 Monitoring

After implementing, monitor your Firebase console:
- **Usage tab** → **Cloud Firestore** → **Reads**
- Should see dramatic drop from 6K+/hour to <100/hour
- Snapshot listeners should show 0-1 instead of 7

## 📝 Notes

- Cache duration is 5 minutes (can be adjusted in DataProvider.js)
- Manual refresh always bypasses cache
- Settings listener in Appbar.jsx is acceptable (1 document read)
- For truly real-time needs, consider Firebase Realtime Database or specific onSnapshot for critical data only

## 🚀 Next Steps

1. Complete the Home.jsx updates (replace all `loading` checks)
2. Update Menu.jsx following the template above
3. Update all Reservation pages
4. Update ContactForm.jsx
5. Test thoroughly
6. Monitor Firebase usage for 24 hours
7. Adjust cache duration if needed

---

**Estimated time to complete**: 2-3 hours
**Expected cost savings**: ~$18/month (Free tier restored)
**Performance improvement**: Faster page loads (no waiting for Firestore)
