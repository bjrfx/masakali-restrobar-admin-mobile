import React from 'react'

const DropZone = () => {
  return (
    <div>DropZone</div>
  )
}

export default DropZone