import React from 'react'

const FileUpload = () => {
  return (
    <div>FileUpload</div>
  )
}

export default FileUpload