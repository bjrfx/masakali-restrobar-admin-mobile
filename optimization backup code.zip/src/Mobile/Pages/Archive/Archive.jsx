import React from 'react'

const Archive = () => {
  return (
    <div>Archive</div>
  )
}

export default Archive