import React, { createContext, useState, useEffect, useContext, useCallback } from 'react';
import { db } from './firebase';
import { collection, getDocs, doc, getDoc, query, where, orderBy, limit } from 'firebase/firestore';
import { useAuth } from './AuthProvider';

const DataContext = createContext();

export const DataProvider = ({ children }) => {
  const { currentUser } = useAuth();
  
  // Cached data
  const [reservations, setReservations] = useState([]);
  const [menuItems, setMenuItems] = useState([]);
  const [contacts, setContacts] = useState([]);
  const [userSettings, setUserSettings] = useState(null);
  
  // Loading states
  const [loading, setLoading] = useState({
    reservations: true,
    menu: true,
    contacts: true,
    settings: true,
  });

  // Last fetch timestamps to prevent over-fetching
  const [lastFetch, setLastFetch] = useState({
    reservations: null,
    menu: null,
    contacts: null,
    settings: null,
  });

  // Cache duration (5 minutes)
  const CACHE_DURATION = 5 * 60 * 1000;

  // Check if cache is still valid
  const isCacheValid = (key) => {
    if (!lastFetch[key]) return false;
    return Date.now() - lastFetch[key] < CACHE_DURATION;
  };

  // Fetch reservations (only when needed)
  const fetchReservations = useCallback(async (forceRefresh = false) => {
    if (!forceRefresh && isCacheValid('reservations')) {
      return reservations;
    }

    try {
      setLoading(prev => ({ ...prev, reservations: true }));
      const reservationsRef = collection(db, 'AllReservations');
      const snapshot = await getDocs(reservationsRef);
      const data = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      setReservations(data);
      setLastFetch(prev => ({ ...prev, reservations: Date.now() }));
      return data;
    } catch (error) {
      console.error('Error fetching reservations:', error);
      return [];
    } finally {
      setLoading(prev => ({ ...prev, reservations: false }));
    }
  }, [reservations]);

  // Fetch menu items (only when needed)
  const fetchMenuItems = useCallback(async (forceRefresh = false) => {
    if (!forceRefresh && isCacheValid('menu')) {
      return menuItems;
    }

    try {
      setLoading(prev => ({ ...prev, menu: true }));
      const menuRef = collection(db, 'menu');
      const snapshot = await getDocs(menuRef);
      const data = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      setMenuItems(data);
      setLastFetch(prev => ({ ...prev, menu: Date.now() }));
      return data;
    } catch (error) {
      console.error('Error fetching menu:', error);
      return [];
    } finally {
      setLoading(prev => ({ ...prev, menu: false }));
    }
  }, [menuItems]);

  // Fetch contacts (only recent ones, limited)
  const fetchContacts = useCallback(async (forceRefresh = false) => {
    if (!forceRefresh && isCacheValid('contacts')) {
      return contacts;
    }

    try {
      setLoading(prev => ({ ...prev, contacts: true }));
      const contactsRef = collection(db, 'contactForm');
      // Only fetch recent 50 contacts to reduce reads
      const contactsQuery = query(
        contactsRef,
        orderBy('createdAt', 'desc'),
        limit(50)
      );
      const snapshot = await getDocs(contactsQuery);
      const data = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      setContacts(data);
      setLastFetch(prev => ({ ...prev, contacts: Date.now() }));
      return data;
    } catch (error) {
      console.error('Error fetching contacts:', error);
      return [];
    } finally {
      setLoading(prev => ({ ...prev, contacts: false }));
    }
  }, [contacts]);

  // Fetch user settings (only when needed)
  const fetchUserSettings = useCallback(async (forceRefresh = false) => {
    if (!currentUser) return null;
    
    if (!forceRefresh && isCacheValid('settings')) {
      return userSettings;
    }

    try {
      setLoading(prev => ({ ...prev, settings: true }));
      const userDocRef = doc(db, 'users', currentUser.uid);
      const docSnapshot = await getDoc(userDocRef);
      const data = docSnapshot.exists() ? docSnapshot.data() : null;
      setUserSettings(data);
      setLastFetch(prev => ({ ...prev, settings: Date.now() }));
      return data;
    } catch (error) {
      console.error('Error fetching user settings:', error);
      return null;
    } finally {
      setLoading(prev => ({ ...prev, settings: false }));
    }
  }, [currentUser, userSettings]);

  // Initial data load (only once)
  useEffect(() => {
    if (currentUser) {
      fetchReservations();
      fetchMenuItems();
      fetchContacts();
      fetchUserSettings();
    }
  }, [currentUser]); // Only run when user changes

  // Invalidate cache helper
  const invalidateCache = (key) => {
    setLastFetch(prev => ({ ...prev, [key]: null }));
  };

  const value = {
    // Data
    reservations,
    menuItems,
    contacts,
    userSettings,
    
    // Loading states
    loading,
    
    // Fetch functions (with caching)
    fetchReservations,
    fetchMenuItems,
    fetchContacts,
    fetchUserSettings,
    
    // Cache management
    invalidateCache,
    
    // Direct setters (for manual updates after mutations)
    setReservations,
    setMenuItems,
    setContacts,
    setUserSettings,
  };

  return (
    <DataContext.Provider value={value}>
      {children}
    </DataContext.Provider>
  );
};

export const useData = () => {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error('useData must be used within DataProvider');
  }
  return context;
};
